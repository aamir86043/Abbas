# Saathi AI frontend
Static site (index.html at repo root). Backend URL is set in js/config.js -> API_BASE.
Host on GitHub Pages (Settings > Pages > Deploy from branch > main / root). Camera, mic and GPS need HTTPS.
